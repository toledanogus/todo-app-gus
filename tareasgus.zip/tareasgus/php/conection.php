<?php
/* $conn = mysqli_connect('localhost', 'root', '', 'tareas') or die(mysqli_error($conn)); */
$conn = mysqli_connect('localhost', 'toledan1_gus', 'sfreud1978', 'toledan1_pedrueza') or die(mysqli_error($conn));
?>